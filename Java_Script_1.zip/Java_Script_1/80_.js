
// class keyword 


class CreateUser{
constructor(firstName, lastName, email, age, address){
this.firstName = firstName;
this.lastName = lastName;
this.email = email;
 this.age = age;
        this.address = address;
    }

about(){
  return `${this.firstName} is ${this.age} years old.`;
}
is18(){
    return this.age >= 18;
}
sing(){
return "la la la la ";
    }

}
const user1 = new CreateUser('chirag', 'ansh', 'chirag@gmail.com', 18, "my address");
const user2 = new CreateUser('jatin ', 'ansh', 'chirag@gmail.com', 19, "my address");
const user3 = new CreateUser('rohit', 'ansh', 'chirag@gmail.com', 17, "my address");

console.log(user1)
console.log(Object.getPrototypeOf(user1));

