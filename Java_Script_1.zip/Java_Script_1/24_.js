// for loop in array


let fruits=["apple","banana","chery","grap"];
for(let i=0;i<=fruits.length;i++){
    console.log(fruits[i].toUpperCase());
    }    