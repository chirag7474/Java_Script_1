// important array methods 

const numbers = [4,2,5,8];



const users = [
 {firstName: "chirag", age: 23},
{firstName: "jatin", age: 21},
{firstName: "sagar", age: 22},
{firstName: "gautam ", age: 20},
]

users.forEach(function(user){
    console.log(user.firstName);
});

