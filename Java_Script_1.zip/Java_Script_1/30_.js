// object
// key =name,age
const person={name:"chirag",age:18};
console.log(person);
console.log(person.name);
console.log(person.age);

// add  key value in object
// 1)
person.gender="male";
console.log(person);
// (2)
person["mobile no"]="7096798390";
console.log(person);