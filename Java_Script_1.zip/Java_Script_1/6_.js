// typeof operator


// data type
// string,number,booleans,undifined,null,BigInt,symbol



let age = 20;
let firstName="chirag"
console.log(typeof age);
console.log(typeof firstName);


// convert number to string
age=age +"";
console.log(typeof age); 


// convert string to number 
let myStr = +"CHIRAG";
console.log(typeof myStr);


let age2 = 20;
age2 =S tring(age2);
console.log(typeof age2);