// trim()
let firstName="    CHIARG       ";
console.log(firstName.length);
firstName=firstName.trim();
console.log(firstName.length);


// uppercase

firstName=firstName.toUpperCase();
console.log(firstName);


// Lowercase

firstName=firstName.toLowerCase();
console.log(firstName);


// SLICE

let newString=firstName.slice(0,4);
console.log(newString);