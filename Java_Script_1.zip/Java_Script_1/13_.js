// and or operator


let firstName="chirag";
let age=22;

// && bey condition true hoy to j print thay
if(firstName[0]==="c" &&  age>18){
    console.log("your name start with c and  age is 22");
} 


//  || bey  mathi 1 condition true hoy toy  print thay


if(firstName[5]==="c" ||  age>35){
    console.log("your name start with c and  age is 22");
} 


// nested if 

let winningNumber=19;
let userGuess=+prompt("guess a number");

if(userGuess===winningNumber){
    console.log("you are right");
}
else{
    if(userGuess < winningNumber){
        console.log("you are low");
    }
    else{
        console.log("you are high") ;
    }



}