

// UNDEFINED
let firstName;
console.log(typeof firstName);
firstName="CHIRAG";
console.log(typeof firstName);



// NULL


console.log(typeof null);
// bug error in js


// BigInt jetla num leva hoy etla lay ski 
let myNumber = BigInt(112122122122212212121212121212121212120);
console.log(myNumber)