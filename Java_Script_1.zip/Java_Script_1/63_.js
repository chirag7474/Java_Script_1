// clone using Object.assign 

// memory  

const obj = {
    key1: "value1",
    key2: "value2"
}
// const obj2=obj; bey ma add krvi krvi hoy to 
 const obj2={...obj};// khali ek ma j add kravi hoy to spread operator no use krvo
obj.key3="value";
console.log(obj);
console.log(obj2);