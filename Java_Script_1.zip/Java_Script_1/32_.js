
// how to iterate Object

const person={
    name:"chirag",
    age:18
};

// // for in loop 


// for(let key in person){
//     console.log(key ,":",person[key]);
// }




// array he ke nahi check krne ke liye

const val= Array.isArray((Object.keys(person)));
console.log(val);

// for of se value

for(let key of Object.keys(person)){
    console.log(key,":",person[key]);
}