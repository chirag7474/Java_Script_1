// // while loop

// // let i=0;
// // whille(i>=3){
// // console.log(i);
// // i++;
// // }

// // exmple


// let total=10;
// let c = 1;
// while(c<=10){

//     total = total+c;
//     c++;
// }
// console.log(total);
let num =10;
let total=(num*(num+1)/2);
console.log(total)