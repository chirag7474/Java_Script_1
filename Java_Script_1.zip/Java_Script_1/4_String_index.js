// string indexing 0 thi start thay
let firstName="chirag";

console.log(firstName[4]);

// length start from 1

console.log(firstName.length);