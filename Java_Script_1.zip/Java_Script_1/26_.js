// while loop in array

const fruits=["apple" ,"mango"];
let i=0;
while(i<fruits.length){
    console.log(fruits[i]);
}