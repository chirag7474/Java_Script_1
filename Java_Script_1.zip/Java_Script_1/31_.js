// diffrence between dot . and bracket nation[]

const key="email";

const person={
    name:"chirag",
    age:18
};
// person.key thi key print thay che email print  nathi thatu
// person.key="chiraglavani1@gmail.com";
// console.log(person);

person[key]="chiraglalvani@gmail.com";
console.log(person); 