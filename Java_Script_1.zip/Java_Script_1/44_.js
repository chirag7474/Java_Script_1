// block scope vs function scope 


// let and const are block scope {} aani andr j call thy ske{} aani bar call krva jay to error aave

// var is function scope  aama thy ske aakhi file ma

// if(true){
//     var firstName = "chirag";
//     console.log(firstName);
// }

// console.log(firstName);

function myApp(){
if(true){
   var firstName = "chirag";
   console.log(firstName);
    }
if(true){
    console.log(firstName);
    }
    console.log(firstName);
}

myApp();