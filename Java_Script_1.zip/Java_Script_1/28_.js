// for in loop

const fruits=["mango","bannana","grap"];
for(let index in fruits ){
    console.log(fruits[index]);
}