function hello(){
    console.log("hello world");
}


//  prototype aapdne function khali space aape che jenathi aapde kay pan add kri ski khali function ma j 

hello.prototype.abc = "abc";
hello.prototype.xyz = "xyz";
hello.prototype.sing = function(){
    return "lalalla";
};
console.log(hello.prototype);
