// if
// else if
// else if
// else


let tempInDegree = 21;
if(tempInDegree<0){

console.log(" so cold outside");

}else if(tempInDegree<16){

    console.log("cold outside");
    
    }
    else if(tempInDegree<25){

        console.log("okay");
        
        }
        else if(tempInDegree<35){

            console.log("go for swim");
            
            }
            else if(tempInDegree<45){

                console.log("turn ac ");
                
                }
                else {

                    console.log("hot");
                    
                    }
               