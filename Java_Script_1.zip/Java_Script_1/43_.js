// lexical scope 
const myVar = "value1";

function myApp(){
    

    function myFunc(){
        // const myVar = "value59";
        const myFunc2 = () =>{
            console.log("inside myFunc", myVar); //pela potana function check kerse ema value hoy to lay lese ane ema no hoy to bija function mathi lay lese ane function ma na hoy to global check krse//       
         }
        myFunc2();
    }


    console.log(myVar);
    myFunc();
}

myApp();