// array  etle ek thi vadhre value store krva mate

let food=["indian","italic","nepali"];
let number=[1,2,3,4];
let mixed=[1,2,3,4,"string",null,undefined];
console.log(food[2]);
console.log(number);
console.log(mixed);

// e value kadhi ne biji umervi hoy to

let food2=["indian","italic","nepali"];
food2[2]="american";
console.log(food2);

//array che nahi te check krvu hoy to

let food3=["indian","italic","nepali"];
console.log(Array.isArray(food3));