// hoisting 
// functon dec ma function pela call kravi to out aaave pan function expression,arrow ma no thay 
hello( ); 


function hello(){
    console.log("hello world");
}
// console.log(hello);
// const hello = "hello world";
// console.log(hello);