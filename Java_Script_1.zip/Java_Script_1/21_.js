// ARRAY PUSH UP AARAY MA VALUE  UMERI SKAY LAST
// ARRAY POP UP ARRAY MA MATHI  VALUE KADHI NAKE LAST VADU 

// // PUSH UP 
// let fruits=["apple","mango","grap"]
// fruits.push("cherry");
// console.log(fruits);

// POP UP

// let fruits3=["apple","mango","grap"]
// // fruits.pop();
// console.log(fruits3);

// PUSH UP 

   
//   

//  unshift pela value umere
let fruits2=["apple","mango","grap"];
console.log(fruits2);
fruits2.unshift("banana");
fruits2.unshift("grean apple");
console.log(fruits2);

// shift pela value remove
let fruits3=["apple","mango","grap"];
console.log(fruits3);
fruits3.shift();
console.log(fruits3);
