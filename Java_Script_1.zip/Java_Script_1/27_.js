
// for of loop

const fruits=["mango","bannana","grap"];
for(let fruit of fruits ){
    console.log(fruit);
}