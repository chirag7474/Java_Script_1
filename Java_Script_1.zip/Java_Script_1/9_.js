// booleans &comprison operator
// true/false
let num1=5;
let num2=7;
console.log(num1>num2);


// == value same che e check kre

let num3=7;
let num4=8;
console.log(num3==num4);


// === value and type bane same che check kre

let num5=7;
let num6=7;
console.log(num5===num6);


// !=  bey same no hoy to true btve


let num7=7;
let num8=8 ;
console.log(num7!=num8);

// !=== value pan same no hoy ane type pan same no hoy to true batve

let num9=7;
let num10="8";
console.log(num9!==num10);