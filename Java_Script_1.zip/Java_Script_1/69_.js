// arrow functions  this not work in arrow func

const user1 = {
    firstName : "chirag",
    age: 8,
    about: () => {
        console.log(this.firstName, this.age);
    }   
}

user1.about(user1);