var value1= 2;
var value1=3;
console.log(value1);

// valid value name $ ,_

var $firstname="sagar lalvani";
console.log($firstname);

var _firstname="sagar lalvani";
console.log(_firstname); 


// let keyword ma ek jeva name no lay ski chnage th ske

let value2= 5;
value2= 6;
console.log(value2);


// const ek jevu biju varriable pan no lay ski and value pan chnage no thay

const pi=3.14

console.log(pi);