// ternary operator
// let age=1;
// let drink="";

// if (age>=5){
//     drink= "cooffe";


// }

// else{
//     drink="milk";
// }

// console.log(drink);


// ternary operator example

let age=78;
let drink=age>=5?"coffe":"milk";
console.log(drink);
