function about(hobby, favMusician){
    console.log(this.firstName, this.age, hobby, favMusician);
}
const user1 = {
    firstName : "chirag",
    age: 8,   
}
const user2 = {
    firstName : "jtin",
    age: 9,
    
}
//  call 
about.call(user1,"gutiar","arjit");
// apply aa array ma beghu lese
about.apply(user1, ["guitar", "bach"]);
// bind function return kre 
const func = about.bind(user2, "guitar", "bach");
func();