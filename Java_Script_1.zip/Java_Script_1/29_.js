// // array destructuring
const myArray=["value1","value2"];
let [myvar1,myvar2]=myArray;
console.log("value of myarray1",myvar1);
console.log("value of  myarray1",myvar2);

// // VMYARRAY2 MA VALUE 3RD NAKHAVI HOY TO EK , MUKAVU

// const myArray=["value1","value2","value3"];
// let [myvar1,,myvar2]=myArray;
// console.log("value of myarray1",myvar1);
// console.log("value of  myarray1",myvar2);

