// find method 

const myArray = ["Hello", "catt", "dog", "lion"];

function isLength3(string){
    return string.length === 3;
}

const ans = myArray.find((string)=>string.length===3);
console.log(ans);

const users = [
    {userId : 1, userName: "chirag"},
    {userId : 2, userName: "chiag"},
    {userId : 3, userName: "jay"},
    {userId : 4, userName: "chintu"},
    {userId : 5, userName: "jatin"},
];

const myUser = users.find((user)=>user.userId===3);
console.log(myUser);