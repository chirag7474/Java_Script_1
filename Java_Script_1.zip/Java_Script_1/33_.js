// computed properties

const key1="objkey1";
const key2="objkey2";

const value1="chirag";
const value2="lalvani";

// aam lkhva thi key1=chirag lakhel aavse  aapdne ne objkey1=chirag joy ena mate niche mubj krvu
// const obj={

//     key1:value1,
//     key2:value2
    
//     }


const obj={

[key1]:value1,
[key2]:value2

}
console.log(obj);


const obj2 ={};
obj2[key1]=value1;
obj2[key2]=value2;
console.log(obj2);