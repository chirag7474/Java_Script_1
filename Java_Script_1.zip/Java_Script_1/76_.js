// proto e refarance   che ek obj mathi no mde to   bija pase leva jayt
// prototype e function ni andr khali space aape jema aapdne kay add krvu hoy to niche alg thi kri ski
function createUser(firstName, lastName, email, age, address){
    const user = Object.create(createUser.prototype);// {}
    user.firstName = firstName;
    user.lastName = lastName;
    user.email = email;
    user.age = age;
    user.address = address;
    return user;
}
createUser.prototype.about = function(){
    return `${this.firstName} is ${this.age} years old.`;
};
createUser.prototype.is18 = function (){
    return this.age >= 18; 
}
createUser.prototype.sing = function (){
    return "la la la la ";
}


const user1 = createUser('chirag', 'vastal', 'chirag@gmail.com', 18, "my address");
const user2 = createUser('chintu', 'vastal', 'chirag@gmail.com', 19, "my address");
const user3 = createUser('mahesh', 'vastal', 'chirag@gmail.com', 17, "my address");
console.log(user1);
console.log(user1.sing());
console.log(user1.is18());
console.log(user1.about());