// optional chaining  error nahi aape undefined dekadse

const user  = {
    firstName: "chirag",
    // address: {houseNumber: '1234'}
}



console.log(user .firstName);
console.log(user?.address?.houseNumber);