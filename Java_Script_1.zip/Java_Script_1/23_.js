// how to colne array 

let  array3=["item3","item4"];
// slice

// let array4=  array3.slice(0)
// let array4=  array3.slice(0).concat(["item5","item6"]);

// concat

// let array4= [].concat(array3);
// let array4= [].concat(array3,["item5","item6"]);


// spread operator
let array4=[...array3]
// let array4=[...array3,...["item5","item6"]];


array3.push("item5");


console.log(array3);
console.log(array4);
