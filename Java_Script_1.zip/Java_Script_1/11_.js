// IF ELSE 
let age=18;
if(age>18){
console.log("you got liecsnse");

}
else{

    console.log("you are not got liecsnse");
}


let num = 12;
if(num%2===0){
    console.log("even");
}
else{
    console.log("odd");

}