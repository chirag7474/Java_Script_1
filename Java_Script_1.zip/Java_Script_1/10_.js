// truthy and falsy value
// var ma kay value hoy to e truthy kevay
//  agr var ma false,"",null,undefined,0 aa badhi value hoy to te falsy value kevay
  
let firstName="";

if(firstName){

    console.log(firstName);
}
else{
    console.log("empty");  
}