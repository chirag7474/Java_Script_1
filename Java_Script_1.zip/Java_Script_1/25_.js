//  use of const in array
// const ne change no kri  ski pan tema function ni  help thi umeri ski


const fruits=["apple","banana"]; 

fruits.push("mango");

console.log(fruits);