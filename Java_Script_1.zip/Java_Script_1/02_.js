
"use strict";


// declare var



    var firstName = "chirag";

    //use var

    console.log(firstName);

    //change var
    firstName = "lalvani";
    
    console.log(firstName);