// splice method 
// start , delete , insert 

const myArray = ['item1', 'item2', 'item3'];


const deletedItem = myArray.splice(1, 2);
console.log("delted item", deletedItem); 

const myArray2 = ['item1', 'item2', 'item3'];
 const insertItem=myArray2.splice(1, 0,'inserted item');
console.log(myArray2); 
// // insert and delete 
const myArray3 = ['item1', 'item2', 'item3'];
const deletedItem3= myArray3.splice(1, 2, "inserted item1", "inserted item2")
console.log("delted item", deletedItem3);
console.log(myArray3);